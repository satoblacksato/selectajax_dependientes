@extends('layouts.layout')

@section('title', 'DesRueda')

@section('content')
  <div class="row">
    <div class="col s12 cyan darken-3 white-text">
      <h3 class="center-align">Ubicación</h3>
    </div>
    <div class="row">
      <div class="col s12 m4 l4">
        <label>Región</label>
        <select class="browser-default" onchange="select_ciudad(this.value)">
          <option value="0" selected>Elija una opción</option>
          @foreach($regiones as $r)
            <option value="{{$r->id}}">{{$r->nombre}}</option>
          @endforeach
        </select>
      </div>
      <div class="col s12 m4 l4">
        <label>Ciudad</label>
        <select id="ciudad" class="browser-default" onchange="select_comuna(this.value)">
          <option value="0" selected>---</option>
        </select>
      </div>
      <div class="col s12 m4 l4">
        <label>Comuna</label>
        <select id="comuna" class="browser-default">
          <option value="0" selected>---</option>
        </select>
      </div>
    </div>
  </div>
@stop
