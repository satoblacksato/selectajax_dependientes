<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Comuna extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::create('communes', function (Blueprint $table) {
          $table->increments('id');
          $table->string('nombre')->index();
          $table->timestamp('created_at');

          $table->integer('ciudad_id')->unsigned();
          $table->foreign('ciudad_id')->references('id')->on('cities');
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
