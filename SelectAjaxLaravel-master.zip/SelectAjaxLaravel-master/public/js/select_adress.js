//Variable global con la url base de la aplicacion
var server = 'http://' + window.location.host + '/'
//Trae las ciudades de acuerdo a la region
function select_ciudad(idciudad){
  var datos = {region: idciudad, path:'adress/getciudad'}
	var proceso = capsula(datos)
	var data = proceso.json
  var html = '<option>Elija una opción</option>'
  //evaluar si el objeto contiene datos
  if(data.estado){
    $.each(data.ciudades,function(){
      html+='<option value="'+this.id+'">'+this.nombre+'</option>'
    })
    //llenar el select>option
    $("#ciudad").html(html)
    //si se cambia el valor del select Region, limpiar los demas select's
    $("#comuna").html('<option value="0">---</option>')
  }else{
    //Notificar que no se encontraron datos
    Materialize.toast('No hay ciudades que conicidan :(', 4000)
    //Limpiar los select's
    html ='<option value="0">---</option>'
    $("#ciudad").html(html)
    $("#comuna").html(html)
  }
}
//Trae las comunas de acuerdo a la ciudad
function select_comuna(idcomuna){
  var datos = {comuna:idcomuna, path:'adress/getcomuna/'}
	var proceso = capsula(datos)
	var data = proceso.json
  var html = '<option>Elija una opción</option>'
  //Evaluar si el objeto contiene datos
  if(data.estado){
    $.each(data.comunas,function(){
      html+='<option value="'+this.id+'">'+this.nombre+'</option>'
    })
    //Llenar el select>option
    $("#comuna").html(html)
  }else{
    //Notificar que no se encontraron datos
    Materialize.toast('No hay comunas que conicidan :(', 4000)
    //Limpiar los select
    html ='<option value="0">---</option>'
    $("#comuna").html(html)
  }
}
//Funcion para evitar la repeticion del codigo ajax de Jquery (DRY Dont repeat yourself)
function capsula(obj) {

    var procesar = $.ajax({
        url: server + obj.path,
        type: 'post',
        headers: {
          'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        },
        dataType: 'json',
        async: false,
        data: obj,
    })

    var resultado = {

       fuente: procesar.responseText,
       json: JSON.parse(procesar.responseText)
    }

    return resultado

}
