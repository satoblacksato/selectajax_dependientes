<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Region;
use App\City;
use App\Commune;

class AdressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {

      $estado = false;
      //realizar query con ORM de eloquent
      $regions_result = Region::all();
      if(count($regions_result) > 0)
      {
        //cambiar el estado si se encontraron de datos
        $estado = true;
      }
      //Retornar la vista con los parametros resultantes de la query anterior(regiones)
      return view("select_views/select_view",['regiones'  =>  $regions_result,'estado' => $estado]);
    }

    public function get_ciudad(Request $request){

      $estado = false;
      //recuperar el parametro recibido por ajax
      $region_parametro = $request->input('region');
      //realizar query con ORM de eloquent
      $ciudad_result = City::where('region_id', $region_parametro)->orderBy('nombre','asc')->get();
      //comprobar si encontro datos la query
      if(count($ciudad_result) > 0){
        $estado = true;
      }
      //retornar los datos en formato JSON
      return response()->json(['ciudades' => $ciudad_result, 'estado' => $estado]);
    }

    public function get_comuna(Request $request){
      $estado = false;
      //recuperar el parametro recibido por ajax
      $comuna_parametro = $request->input('comuna');
      //realizar query con ORM de eloquent
      $comuna_result = Commune::where('ciudad_id', $comuna_parametro)->orderBy('nombre','asc')->get();
      //comprobar si encontro datos la query
      if(count($comuna_result) > 0){
        $estado = true;
      }
      //retornar los datos en formato JSON
      return response()->json(['comunas' => $comuna_result, 'estado' => $estado]);
    }
}
